package Utilities.Algorithm;

public interface Algorithm {
    String toString();
    long getNanoRuntime();
    double getRuntime();
}
